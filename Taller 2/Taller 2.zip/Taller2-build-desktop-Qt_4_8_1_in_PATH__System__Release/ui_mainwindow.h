/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Tue Mar 10 00:03:38 2015
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QStatusBar>
#include <QtGui/QTabWidget>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *loadImage;
    QTabWidget *tabWidget;
    QWidget *tab;
    QPushButton *reduce;
    QPushButton *extend;
    QWidget *tab_2;
    QComboBox *colorFormat;
    QPushButton *ColorSpace;
    QWidget *tab_3;
    QComboBox *thresholdType;
    QCheckBox *thresholdBW;
    QLabel *thresholdValueLabel;
    QSpinBox *thresholdValue;
    QLabel *thresholdMaxValueLabel;
    QSpinBox *thresholdMaxValue;
    QPushButton *umbralizar;
    QFrame *line;
    QPushButton *umbralAutomatico;
    QComboBox *automaticThresholdType;
    QWidget *tab_4;
    QPushButton *experiment1;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(496, 367);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        loadImage = new QPushButton(centralWidget);
        loadImage->setObjectName(QString::fromUtf8("loadImage"));
        loadImage->setGeometry(QRect(10, 0, 99, 27));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setEnabled(false);
        tabWidget->setGeometry(QRect(10, 30, 471, 271));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        reduce = new QPushButton(tab);
        reduce->setObjectName(QString::fromUtf8("reduce"));
        reduce->setGeometry(QRect(0, 10, 99, 27));
        extend = new QPushButton(tab);
        extend->setObjectName(QString::fromUtf8("extend"));
        extend->setGeometry(QRect(110, 10, 99, 27));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        colorFormat = new QComboBox(tab_2);
        colorFormat->setObjectName(QString::fromUtf8("colorFormat"));
        colorFormat->setGeometry(QRect(0, 20, 85, 27));
        ColorSpace = new QPushButton(tab_2);
        ColorSpace->setObjectName(QString::fromUtf8("ColorSpace"));
        ColorSpace->setGeometry(QRect(100, 20, 141, 27));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        thresholdType = new QComboBox(tab_3);
        thresholdType->setObjectName(QString::fromUtf8("thresholdType"));
        thresholdType->setGeometry(QRect(0, 10, 161, 27));
        thresholdBW = new QCheckBox(tab_3);
        thresholdBW->setObjectName(QString::fromUtf8("thresholdBW"));
        thresholdBW->setGeometry(QRect(200, 50, 151, 22));
        thresholdValueLabel = new QLabel(tab_3);
        thresholdValueLabel->setObjectName(QString::fromUtf8("thresholdValueLabel"));
        thresholdValueLabel->setGeometry(QRect(210, 20, 50, 17));
        thresholdValue = new QSpinBox(tab_3);
        thresholdValue->setObjectName(QString::fromUtf8("thresholdValue"));
        thresholdValue->setGeometry(QRect(270, 20, 61, 27));
        thresholdValue->setMaximum(256);
        thresholdValue->setValue(100);
        thresholdMaxValueLabel = new QLabel(tab_3);
        thresholdMaxValueLabel->setObjectName(QString::fromUtf8("thresholdMaxValueLabel"));
        thresholdMaxValueLabel->setGeometry(QRect(10, 40, 91, 17));
        thresholdMaxValue = new QSpinBox(tab_3);
        thresholdMaxValue->setObjectName(QString::fromUtf8("thresholdMaxValue"));
        thresholdMaxValue->setGeometry(QRect(90, 40, 61, 27));
        thresholdMaxValue->setMaximum(256);
        thresholdMaxValue->setValue(256);
        umbralizar = new QPushButton(tab_3);
        umbralizar->setObjectName(QString::fromUtf8("umbralizar"));
        umbralizar->setGeometry(QRect(340, 50, 121, 27));
        line = new QFrame(tab_3);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(200, 80, 261, 20));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        umbralAutomatico = new QPushButton(tab_3);
        umbralAutomatico->setObjectName(QString::fromUtf8("umbralAutomatico"));
        umbralAutomatico->setGeometry(QRect(310, 110, 151, 27));
        automaticThresholdType = new QComboBox(tab_3);
        automaticThresholdType->setObjectName(QString::fromUtf8("automaticThresholdType"));
        automaticThresholdType->setGeometry(QRect(200, 110, 101, 27));
        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        experiment1 = new QPushButton(tab_4);
        experiment1->setObjectName(QString::fromUtf8("experiment1"));
        experiment1->setGeometry(QRect(10, 20, 121, 27));
        tabWidget->addTab(tab_4, QString());
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 496, 25));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        loadImage->setText(QApplication::translate("MainWindow", "Cargar Im\303\241gen", 0, QApplication::UnicodeUTF8));
        reduce->setText(QApplication::translate("MainWindow", "Reducir 50%", 0, QApplication::UnicodeUTF8));
        extend->setText(QApplication::translate("MainWindow", "Ampliar 50%", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Tama\303\261o", 0, QApplication::UnicodeUTF8));
        colorFormat->clear();
        colorFormat->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Gray", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "XYZ", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "HSV", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "HLS", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "LUV", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "YCrCb", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "BGR", 0, QApplication::UnicodeUTF8)
        );
        ColorSpace->setText(QApplication::translate("MainWindow", "Espacio de Color", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "Espacio de Color", 0, QApplication::UnicodeUTF8));
        thresholdType->clear();
        thresholdType->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "BINARY", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "BINARY-INV", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "TRUNC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "TOZERO-INV", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "TOZERO", 0, QApplication::UnicodeUTF8)
        );
        thresholdBW->setText(QApplication::translate("MainWindow", "Blanco y Negro", 0, QApplication::UnicodeUTF8));
        thresholdValueLabel->setText(QApplication::translate("MainWindow", "Umbral", 0, QApplication::UnicodeUTF8));
        thresholdMaxValueLabel->setText(QApplication::translate("MainWindow", "Max Value", 0, QApplication::UnicodeUTF8));
        umbralizar->setText(QApplication::translate("MainWindow", "Umbralizar", 0, QApplication::UnicodeUTF8));
        umbralAutomatico->setText(QApplication::translate("MainWindow", "Umbral Autom\303\241tico", 0, QApplication::UnicodeUTF8));
        automaticThresholdType->clear();
        automaticThresholdType->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Mean C", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Gaussian C", 0, QApplication::UnicodeUTF8)
        );
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainWindow", "Umbralizaci\303\263n", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        experiment1->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Realiza una Umbralizaci\303\263n de RGB a Gris, conviertiendo la imagen a Blanco y negro y luego umbralizando o umbralizando primero y luego convirtiendo a Blanco y negro. Los valores usados son los definidos en la pesta\303\261a &quot;Umbralizaci\303\263n&quot;</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        experiment1->setText(QApplication::translate("MainWindow", "Experimento 1", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("MainWindow", "Experimentos", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
